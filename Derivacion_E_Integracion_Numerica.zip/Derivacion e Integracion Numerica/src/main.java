import java.util.*;

import javax.script.*;

import java.lang.*;

public class main {

	static ScriptEngineManager manager = new ScriptEngineManager();
	static ScriptEngine engine = manager.getEngineByName("js");
	
	public static void main(String[] args) 
	{
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// MENU INICIAL																									////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
		
		menuInicial();
        
	}
	
	public static void menuInicial()
	{
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// MENU INICIAL																									////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		System.out.println("");
		System.out.println("Elige una opci�n"); 
		System.out.println("0.- Salir ");
		System.out.println("1.- Integraci�n - Relga del Trapecio Multiple");
		System.out.println("2.- Integraci�n - Regla Simpson 1/3");
		System.out.println("3.- Integraci�n - Regla Sumpson 3/8");
		System.out.println("4.- Diferenciaci�n - Diferencia Divididas Finitas");
		System.out.println("5.- Secante");
		System.out.println("6.- Ayuda");
		
		
		System.out.println("Digite la opci�n deseada: "); 
		String opcion = "";
		Scanner entrada = new Scanner(System.in);
		opcion = entrada.nextLine ();
		
		if( opcion.equals("0"))
		{
			System.out.println("Gracias por usar el programa. ");
		}	
		
		else if( opcion.equals("1"))
		{
			try {
				trapecioMultiple();
			} catch (ScriptException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
		else if( opcion.equals("2"))
		{
			try {
				simpson1();
			} catch (ScriptException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		 
		else if( opcion.equals("3"))
		{
			try {
				simpson3();
			} catch (ScriptException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
		
		else if( opcion.equals("4"))
		{
			try {
				derivacion();
			} catch (ScriptException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(opcion.equals("6"))
		{
			menuDeAyuda();
		}
		else
		{
			System.out.println("Por favor escriba una opcion valida.");
			menuInicial();
		}
		
	}
	/** 
	 * Metodo cerrado de biseccion
	 * @throws ScriptException 
	 */
	private static void trapecioMultiple() throws ScriptException 
	{
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// Asignacion de Datos para el metodo de trapecio Multiple														////										////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		
		System.out.println("Metodo de Integraci�n - Regla del trapecio multiple, por favor digite los siguientes valores:");
		
		System.out.println("Digite la ecuaci�n: ");
		String fx = "";
		Scanner entrada = new Scanner(System.in);
		fx = entrada.nextLine ();
		
		System.out.println("Digite el valor de a (L�mite Inferior): ");
		String xls = "";
		Scanner entrada2 = new Scanner(System.in);
		xls = entrada2.nextLine ();
		
		System.out.println("Digite el valor de b (L�mite Superior): ");
		String xus = "";
		Scanner entrada3 = new Scanner(System.in);
		xus = entrada3.nextLine ();		
		
		System.out.println("Digite el numero de Iteraciones");
		String iteraciones = "";
		Scanner entrada5 = new Scanner(System.in);
		iteraciones = entrada5.nextLine ();
		
		System.out.println("Digite el valor de la Integral Real: ");
		String raizs = "";
		Scanner entrada4 = new Scanner(System.in);
		raizs = entrada4.nextLine ();
		
		double a = Double.parseDouble(xls);
		double b = Double.parseDouble(xus);
		double integral = Double.parseDouble(raizs);
		int n = Integer.parseInt(iteraciones);
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// Recorrido para el calculo completo																				////										////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		//Variables auxiliares
		
		double fxi = 0;
		double Xi = a;
		double tamTrapecio = (b -a)/n;
		double sumfx= 0;
		double fx0 = 0;
		double fxn = 0;
		double integralNumerica = 0;
		
		System.out.println("");
		System.out.println("I" + "\t \t" + "Xi" + "\t \t" + "Fxi" );

		for (int i = 0; i <= n; i++) 
		{
			if( i == 0)
			{
				fx0 = evaluarExpresion(fx, Xi);
								
				System.out.printf("%d \t \t %.2f \t \t %.8f \n", i, Xi, fx0);
				Xi += tamTrapecio;
				continue;
			}
			else if( i == n)
			{
				fxn = evaluarExpresion(fx, Xi);
								
				System.out.printf("%d \t \t %.2f \t \t %.8f \n", i, Xi, fxn);
				continue;
			}
			fxi = evaluarExpresion(fx, Xi);
			sumfx += fxi;				
			System.out.printf("%d \t \t %.2f \t  \t %.8f \n", i, Xi, fxi);
			Xi += tamTrapecio;
			
		}
		
		integralNumerica = (b -a)*((fx0 +2*sumfx+fxn)/(2*n));
		double et = Math.abs(((integral - integralNumerica)/integral)*100);
		System.out.println("");
		System.out.printf("La sumatoria F(Xi) del rango i=1 a n-1 es:  %.8f \n", sumfx);
		System.out.println("");
		System.out.printf("La Integral N�merica o Calculada es:  %.8f \n", integralNumerica);
		System.out.println("");
		System.out.printf("El Error Relativo Porcentual Verdadero (et) es:  %.8f \n", et);
		
		reiniciar();
	}
	
	
	/**
	 * Metodo cerrado de falsa posicion
	 * @throws ScriptException 
	 */
	private static void simpson1() throws ScriptException 
	{
		
		
		System.out.println("Metodo de Integraci�n - Regla de Simpson 1/3, por favor digite los siguientes valores:");
		
		System.out.println("Digite la ecuaci�n: ");
		String fx = "";
		Scanner entrada = new Scanner(System.in);
		fx = entrada.nextLine ();
		
		System.out.println("Digite el valor de a (L�mite Inferior): ");
		String xls = "";
		Scanner entrada2 = new Scanner(System.in);
		xls = entrada2.nextLine ();
		
		System.out.println("Digite el valor de b (L�mite Superior): ");
		String xus = "";
		Scanner entrada3 = new Scanner(System.in);
		xus = entrada3.nextLine ();		
		
		System.out.println("Digite el numero de Iteraciones");
		String iteraciones = "";
		Scanner entrada5 = new Scanner(System.in);
		iteraciones = entrada5.nextLine ();
		
		System.out.println("Digite el valor de la Integral Real: ");
		String raizs = "";
		Scanner entrada4 = new Scanner(System.in);
		raizs = entrada4.nextLine ();
		
		double a = Double.parseDouble(xls);
		double b = Double.parseDouble(xus);
		double integral = Double.parseDouble(raizs);
		int n = Integer.parseInt(iteraciones);
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// Recorrido para el calculo completo																				////										////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		//Variables auxiliares
		
		double fxi = 0;
		double Xi = a;
		double tamTrapecio = (b -a)/n;
		double sumPar= 0;
		double sumImpar = 0;
		double fx0 = evaluarExpresion(fx, a);
		double fxn = evaluarExpresion(fx, b);
		double integralNumerica = 0;
		
		System.out.println("");
		System.out.println("I" + "\t \t" + "Xi" + "\t \t" + "Fxi Impar" + "\t \t" + "Fxi Par");
		
		for (int i = 0; i <= n; i++) 
		{
			if(i%2 == 0.0)
			{
				fxi = evaluarExpresion(fx, Xi);
				if(i!=0 &&  i!= n)
				{
					sumPar += fxi;
				}				
				System.out.printf("%d \t \t %.2f \t \t \t \t \t  %.8f \n", i, Xi, fxi);
				Xi += tamTrapecio;
				
			}
			else 
			{
				fxi = evaluarExpresion(fx, Xi);
				sumImpar += fxi;				
				System.out.printf("%d \t \t %.2f \t \t %.8f \n", i, Xi, fxi);
				Xi += tamTrapecio;
				
			}
			
			
		}
		
		integralNumerica = (b -a)*((fx0 +4*sumImpar+2*sumPar+fxn)/(3*n));
		double et = Math.abs(((integral - integralNumerica)/integral)*100);
		System.out.println("");
		System.out.printf("La sumatoria F(Xi) Impar es:  %.8f \n", sumImpar);
		System.out.println("");
		System.out.printf("La sumatoria F(Xi) Par es:  %.8f \n", sumPar);
		System.out.println("");
		System.out.printf("La Integral N�merica o Calculada es:  %.8f \n", integralNumerica);
		System.out.println("");
		System.out.printf("El Error Relativo Porcentual Verdadero (et) es:  %.8f \n", et);
		
		reiniciar();
	}

	/**
	 * Metodo abierto de punto fijo
	 * @throws ScriptException 
	 */
	private static void simpson3() throws ScriptException 
	{
		System.out.println("Metodo de Integraci�n - Regla de Simpson 3/8, por favor digite los siguientes valores:");
		
		System.out.println("Digite la ecuaci�n: ");
		String fx = "";
		Scanner entrada = new Scanner(System.in);
		fx = entrada.nextLine ();
		
		System.out.println("Digite el valor de a (L�mite Inferior): ");
		String xls = "";
		Scanner entrada2 = new Scanner(System.in);
		xls = entrada2.nextLine ();
		
		System.out.println("Digite el valor de b (L�mite Superior): ");
		String xus = "";
		Scanner entrada3 = new Scanner(System.in);
		xus = entrada3.nextLine ();		
		
		
		
		System.out.println("Digite el valor de la Integral Real: ");
		String raizs = "";
		Scanner entrada4 = new Scanner(System.in);
		raizs = entrada4.nextLine ();
		
		System.out.println("Digite el numero de Iteraciones");
		String iteraciones = "";
		Scanner entrada5 = new Scanner(System.in);
		iteraciones = entrada5.nextLine ();
		
		double a = Double.parseDouble(xls);
		double b = Double.parseDouble(xus);
		double integral = Double.parseDouble(raizs);
		int n = Integer.parseInt(iteraciones);
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// Recorrido para el calculo completo																				////										////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		//Variables auxiliares
		
		double fxi = 0;
		double Xi = a;
		double tamTrapecio = (b -a)/n;
		double sum1= 0;
		double sum2 = 0;
		double sum3 = 0;
		double fx0 = evaluarExpresion(fx, a);
		double fxn = evaluarExpresion(fx, b);
		double integralNumerica = 0;
		int estado = 0;
		System.out.println("");
		System.out.println("I" + "\t \t" + "Xi" + "\t \t" + "Fxi(1,4,7)" + "\t \t" + "Fxi(2,5,8)"+ "\t \t" + "Fxi(3,6,9)");
		
		for (int i = 0; i <= n; i++) 
		{
			if( i == 0 )
			{
				System.out.printf("%d \t \t %.2f \t \t \t \t \t  \t \t %.8f \n", i, Xi, fx0);
				Xi += tamTrapecio;
				continue;
			}
			else if( i == n)
			{
				System.out.printf("%d \t \t %.2f \t \t \t \t \t  \t \t %.8f \n", i, Xi, fxn);
				continue;
			}
			if( estado == 0)
			{
				fxi = evaluarExpresion(fx, Xi);
				sum1 += fxi;			
				System.out.printf("%d \t \t %.2f \t \t  %.8f \n", i, Xi, fxi);
				Xi += tamTrapecio;
				estado ++;
				
			}
			else if( estado == 1) 
			{
				fxi = evaluarExpresion(fx, Xi);
				sum2 += fxi;				
				System.out.printf("%d \t \t %.2f \t \t \t \t \t %.8f \n", i, Xi, fxi);
				Xi += tamTrapecio;
				estado ++;
				
			}
			else
			{
				fxi = evaluarExpresion(fx, Xi);
				sum3 += fxi;				
				System.out.printf("%d \t \t %.2f \t \t \t \t \t \t \t %.8f \n", i, Xi, fxi);
				Xi += tamTrapecio;
				estado = 0;
			}
			
			
		}
		
		integralNumerica = ((3*tamTrapecio)/8)*((fx0 +3*sum1+3*sum2+2*sum3+fxn));
		double et = Math.abs(((integral - integralNumerica)/integral)*100);
		System.out.println("");
		System.out.printf("La sumatoria F(Xi) - (1,4,7) es:  %.8f \n", sum1);
		System.out.println("");
		System.out.printf("La sumatoria F(Xi) - (2,5,8) es:  %.8f \n", sum2);
		System.out.println("");
		System.out.printf("La sumatoria F(Xi) - (3,6,9) es:  %.8f \n", sum3);
		System.out.println("");
		System.out.printf("La Integral N�merica o Calculada es:  %.8f \n", integralNumerica);
		System.out.println("");
		System.out.printf("El Error Relativo Porcentual Verdadero (et) es:  %.8f \n", et);
		
		reiniciar();
	}
	
	/**
	 * Metodo abierto de Newton-Rhapson
	 * @throws ScriptException 
	 */
	private static void derivacion() throws ScriptException
	{
System.out.println("Metodo de Integraci�n - Regla de Simpson 1/3, por favor digite los siguientes valores:");
		
		System.out.println("Digite la ecuaci�n: ");
		String fx = "";
		Scanner entrada = new Scanner(System.in);
		fx = entrada.nextLine ();
		
		System.out.println("Digite el valor de xi: ");
		String xls = "";
		Scanner entrada2 = new Scanner(System.in);
		xls = entrada2.nextLine ();
		
		System.out.println("Digite el valor del Tama�o de Paso (h): ");
		String xus = "";
		Scanner entrada3 = new Scanner(System.in);
		xus = entrada3.nextLine ();		
		
		
		
		double xi = Double.parseDouble(xls);
		double h = Double.parseDouble(xus);
		
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// Recorrido para el calculo completo																				////										////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		//Variables auxiliares
		
		double fxsub5 = evaluarExpresion(fx, (xi - 5*h));
		double fxsub4 = evaluarExpresion(fx, (xi - 4*h));
		double fxsub3 = evaluarExpresion(fx, (xi - 3*h));
		double fxsub2 = evaluarExpresion(fx, (xi - 2*h));
		double fxsub1 = evaluarExpresion(fx, (xi - h));
		double fxi = evaluarExpresion(fx, (xi));
		double fxmas1 = evaluarExpresion(fx, (xi + h));
		double fxmas2 = evaluarExpresion(fx, (xi + 2*h));
		double fxmas3 = evaluarExpresion(fx, (xi + 3*h));
		double fxmas4 = evaluarExpresion(fx, (xi + 4*h));
		double fxmas5 = evaluarExpresion(fx, (xi + 5*h));
		
		// Primera derivada Primer metodo
		
		double dx1at1 = (fxi - fxsub1)/(h);
		double dx1c1 = (fxmas1 - fxsub1)/(2*h);
		double dx1ad1 = (fxmas1-fxi)/(h);
		
		// Primera derivada Segundo metodo
		
		double dx1at2 = (3*fxi - 4*fxsub1 + fxsub2)/(2*h);
		double dx1c2 = (-fxmas2 + 8*fxmas1 - 8*fxsub1 + fxsub2)/(12*h);
		double dx1ad2 = (-fxmas2 + 4*fxmas1 - 3*fxi )/(2*h);
		
		// Segunda derivada Primer metodo
		
		double dx2at1 = (fxi -2*fxsub1 + fxsub2)/(h*h);
		double dx2c1 = (fxmas1 -2*fxi + fxsub1)/(h*h);
		double dx2ad1 = (fxmas2 -2*fxmas1+fxi)/(h*h);
		
		// Segunda derivada Segundo metodo
		
		double dx2at2 = (2*fxi - 5*fxsub1 + 4*fxsub2 -fxsub3)/(h*h);
		double dx2c2 = (-fxmas2 + 16*fxmas1 -30*fxi  +16*fxsub1 - fxsub2)/(12*h*h);
		double dx2ad2 = (-fxmas3 + 4*fxmas2 -5* fxmas1 + 2*fxi )/(h*h);
		
		// Tercera derivada segundo metodo
		
		double dx3at2 = (5*fxi - 18*fxsub1 + 24*fxsub2 -14*fxsub3 + 3*fxsub4)/(2*h*h*h);
		double dx3c2 = (-fxmas3 + 8*fxmas2 -13*fxmas1  + 13*fxsub1 - 8*fxsub2 + fxsub3)/(8*h*h*h);
		double dx3ad2 = (-3* fxmas4 + 14*fxmas3 - 24*fxmas2 + 18* fxmas1 -5*fxi )/(2*h*h*h);
		
		// Cuarta derivada segundo metodo
		
		double dx4at2 = (3*fxi - 14*fxsub1 + 26*fxsub2 -24*fxsub3 + 11*fxsub4 -2*fxsub5)/(h*h*h*h);
		double dx4c2 = (-fxmas3 +12*fxmas2 + 39*fxmas1 +56*fxi  -39*fxsub1 + 12*fxsub2 + fxsub3)/(6*h*h*h*h);
		double dx4ad2 = (-2*fxmas5 +11*fxmas4 - 24*fxmas3 + 26*fxmas2 -14* fxmas1 + 3*fxi )/(h*h*h*h);
		
		/**
		System.out.println("");
		System.out.println("\t \t \t \t \t" + " Atras" + "\t \t" + " Centrada" + "\t " + "Adelante");
		System.out.printf("Primera Derivada - Primer M�todo \t %.8f \t %.8f \t %.8f \n", dx1at1, dx1c1, dx1ad1);
		System.out.printf("Primera Derivada - Segundo M�todo \t %.8f \t %.8f \t %.8f \n", dx1at2, dx1c2, dx1ad2);
		System.out.printf("Segunda Derivada - Primer M�todo \t %.8f \t %.8f \t %.8f \n", dx2at1, dx2c1, dx2ad1);
		System.out.printf("Segunda Derivada - Segundo M�todo \t %.8f \t %.8f \t %.8f \n", dx2at2, dx2c2, dx2ad2);
		**/
		System.out.printf("Tercera Derivada - Segundo M�todo \t %.8f \t %.8f \t %.8f \n", dx3at2, dx3c2, dx3ad2);
		System.out.printf("Cuarta Derivada - Segundo M�todo \t %.8f \t %.8f \t %.8f \n", dx4at2, dx4c2, dx4ad2);
		
		reiniciar();
		
	}
	

	
	private static void reiniciar()
	{
		System.out.println("");
		System.out.println("�Desea volver a usar el programa?");
		System.out.println("0.- No ");
		System.out.println("1.- Si");
		
		System.out.println("Digite la opci�n deseada: "); 
		String opcion = "";
		Scanner entrada = new Scanner(System.in);
		opcion = entrada.nextLine ();
		
		if( opcion.equals("0"))
		{
			System.out.println("Gracias por usar el programa. ");
		}
		else if( opcion.equals("1"))
		{
			menuInicial();
		}
		else
		{
			System.out.println("Por favor ingrese un valor valido.");
			reiniciar();
		}
		
	}
	
	private static void menuDeAyuda() 
	{
		// TODO Auto-generated method stub
		System.out.println("");
		System.out.println("Aplicaci�n desarrollada por Jos� Daniel Barrero Barrios");
		reiniciar();
	}
	
	public static double evaluarExpresion(String ecuacion, double valor) throws ScriptException 
	{
		String variable = "@x";
		boolean aux;
		String retorno = new String();
		retorno = ecuacion;
		do {
			retorno = retorno.replace(variable, "("+valor+")");
			aux = retorno.matches(variable);
		} while (aux != false);
		return (double) engine.eval(retorno);
	}
}
	
	


