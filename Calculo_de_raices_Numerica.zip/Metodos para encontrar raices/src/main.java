import java.util.*;

import javax.script.*;

import java.lang.*;

public class main {

	static ScriptEngineManager manager = new ScriptEngineManager();
	static ScriptEngine engine = manager.getEngineByName("js");
	
	public static void main(String[] args) 
	{
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// MENU INICIAL																									////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		menuInicial();
        
	}
	
	public static void menuInicial()
	{
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// MENU INICIAL																									////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		System.out.println("");
		System.out.println("Elige una opci�n"); 
		System.out.println("0.- Salir ");
		System.out.println("1.- Bisecci�n");
		System.out.println("2.- Falsa Posici�n");
		System.out.println("3.- Punto Fijo");
		System.out.println("4.- Newton-Rhapson");
		System.out.println("5.- Secante");
		System.out.println("6.- Ayuda");
		
		
		System.out.println("Digite la opci�n deseada: "); 
		String opcion = "";
		Scanner entrada = new Scanner(System.in);
		opcion = entrada.nextLine ();
		
		if( opcion.equals("0"))
		{
			System.out.println("Gracias por usar el programa. ");
		}
		else if( opcion.equals("1"))
		{
			try {
				biseccion();
			} catch (ScriptException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if( opcion.equals("2"))
		{
			try {
				falsaPosicion();
			} catch (ScriptException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if( opcion.equals("3"))
		{
			try {
				puntoFijo();
			} catch (ScriptException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if( opcion.equals("4"))
		{
			try {
				newtonRhapson();
			} catch (ScriptException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if( opcion.equals("5"))
		{
			try {
				secante();
			} catch (ScriptException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(opcion.equals("6"))
		{
			menuDeAyuda();
		}
		else
		{
			System.out.println("Por favor escriba una opcion valida.");
			menuInicial();
		}
		
	}
	/** 
	 * Metodo cerrado de biseccion
	 * @throws ScriptException 
	 */
	private static void biseccion() throws ScriptException 
	{
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// Asignacion de Datos para el metodo de bisecci�n																////										////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		
		System.out.println("Metodo de bisecci�n, por favor digite los siguientes valores:");
		
		System.out.println("Digite la ecuaci�n: ");
		String fx = "";
		Scanner entrada = new Scanner(System.in);
		fx = entrada.nextLine ();
		
		System.out.println("Digite el valor de Xl: ");
		String xls = "";
		Scanner entrada2 = new Scanner(System.in);
		xls = entrada2.nextLine ();
		
		System.out.println("Digite el valor de Xu: ");
		String xus = "";
		Scanner entrada3 = new Scanner(System.in);
		xus = entrada3.nextLine ();
		
		System.out.println("Digite el valor de la raiz: ");
		String raizs = "";
		Scanner entrada4 = new Scanner(System.in);
		raizs = entrada4.nextLine ();
		
		System.out.println("Digite el numero de Iteraciones");
		String iteraciones = "";
		Scanner entrada5 = new Scanner(System.in);
		iteraciones = entrada5.nextLine ();
		
		
		double xl = Double.parseDouble(xls);
		double xu = Double.parseDouble(xus);
		double raiz = Double.parseDouble(raizs);
		int numi = Integer.parseInt(iteraciones);
		
		
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// Definaci�n de arrays																							////										////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		ArrayList<Double> Xl = new  ArrayList<Double>();
		
		ArrayList<Double> Xu = new  ArrayList<Double>();
		
		ArrayList<Double> Xr = new  ArrayList<Double>();
		
		ArrayList<Double> Fxl = new  ArrayList<Double>();
		
		ArrayList<Double> Fxu = new  ArrayList<Double>();
		
		ArrayList<Double> Fxr = new  ArrayList<Double>();
		
		ArrayList<Double> Fxlfxr = new  ArrayList<Double>();
		
		ArrayList<Double> ea = new  ArrayList<Double>();
			
		ArrayList<Double> et = new  ArrayList<Double>();
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// Recorrido para el calculo completo																				////										////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		//Variable auxiliares
		
		double xr = 0;
		double fxl = 0;
		double fxu = 0;
		double fxr = 0;
		double fxlxr = 0;
		double eaa = 0;
		double ett = 0;
		
		for (int i = 0; i < numi; i++) 
		{
			if( i==0 )
			{
				Xl.add(xl);
				Xu.add(xu);
				xr =  (xl + xu)/2;
				Xr.add(xr);		
				fxl = evaluarExpresion(fx, xl);
				Fxl.add(fxl);
				fxu = evaluarExpresion(fx, xu);
				Fxu.add(fxu);
				fxr = evaluarExpresion(fx, xr);
				Fxr.add(fxr);
				fxlxr= fxl*fxr;
				Fxlfxr.add(fxlxr);	
				ett = Math.abs(((raiz - xr)/raiz)*100);
				et.add(ett);
				ea.add(eaa);				
			}
			else
			{
				if(Fxlfxr.get(i-1) > 0)
				{
					xl = Xr.get(i-1);
					xu = Xu.get(i-1);
				}
				else
				{
					xl = Xl.get(i-1);
					xu = Xr.get(i-1);
				}
				
				xr =  (xl + xu)/2;						
				fxl = evaluarExpresion(fx, xl);				
				fxu = evaluarExpresion(fx, xu);				
				fxr = evaluarExpresion(fx, xr);				
				fxlxr= fxl*fxr;				
				ett = Math.abs(((raiz - xr)/raiz)*100);
				eaa = Math.abs(((xr-Xr.get(i-1))/xr)*100);		
					
				Xl.add(xl);
				Xu.add(xu);
				Xr.add(xr);
				Fxl.add(fxl);
				Fxu.add(fxu);
				Fxr.add(fxr);
				Fxlfxr.add(fxlxr);	
				et.add(ett);
				ea.add(eaa);
			}
		}
		
		imprimirBiseccion(numi,Xl,Xu,Xr,Fxl,Fxu,Fxr,Fxlfxr,et,ea);
		
	}
	
	private static void imprimirBiseccion(int numi, ArrayList<Double> xl, ArrayList<Double> xu, ArrayList<Double> xr,
			ArrayList<Double> fxl, ArrayList<Double> fxu, ArrayList<Double> fxr, ArrayList<Double> fxlfxr,
			ArrayList<Double> et, ArrayList<Double> ea) 
	{
		System.out.println("");
		System.out.println("I" + "\t" + "Xl" + "\t \t" + "Xu" + "\t \t" + "Xr" + "\t \t" + "Fxl" + "\t \t" + "Fxu" + "\t \t" + "Fxr" + "\t \t" + "FxlFxr" + "\t \t" + "Et" + "\t \t" + "Ea");
		
		for (int i = 0; i < numi; i++) 
		{
			System.out.printf("%d \t %.8f \t  %.8f \t %.8f \t %.8f \t %.8f \t %.8f \t %.8f \t %.8f \t %.8f \n", i, xl.get(i),xu.get(i),xr.get(i),fxl.get(i),fxu.get(i),fxr.get(i),fxlfxr.get(i),et.get(i), ea.get(i));
		}
		reiniciar();
	}

	/**
	 * Metodo cerrado de falsa posicion
	 * @throws ScriptException 
	 */
	private static void falsaPosicion() throws ScriptException 
	{
		System.out.println("Metodo de falsa posici�n, por favor digite los siguientes valores:");
		
		System.out.println("Digite la ecuaci�n: ");
		String fx = "";
		Scanner entrada = new Scanner(System.in);
		fx = entrada.nextLine ();
		
		System.out.println("Digite el valor de Xl: ");
		String xls = "";
		Scanner entrada2 = new Scanner(System.in);
		xls = entrada2.nextLine ();
		
		System.out.println("Digite el valor de Xu: ");
		String xus = "";
		Scanner entrada3 = new Scanner(System.in);
		xus = entrada3.nextLine ();
		
		System.out.println("Digite el valor de Estimado: ");
		String estimado = "";
		Scanner entrada6 = new Scanner(System.in);
		estimado = entrada6.nextLine ();
		
		System.out.println("Digite el valor de la raiz: ");
		String raizs = "";
		Scanner entrada4 = new Scanner(System.in);
		raizs = entrada4.nextLine ();
		
		System.out.println("Digite el numero de Iteraciones");
		String iteraciones = "";
		Scanner entrada5 = new Scanner(System.in);
		iteraciones = entrada5.nextLine ();
		

		double xl = Double.parseDouble(xls);
		double xu = Double.parseDouble(xus);
		double raiz = Double.parseDouble(raizs);
		double es = Double.parseDouble(estimado);
		int numi = Integer.parseInt(iteraciones);		
		double xr = 0;
		double antxr= 0;
		double fxl = 0;
		double fxu = 0;
		double fxr = 0;
		double fxlfxr = 0;
		double ea = 1;
		double et = 0;
		
		System.out.println("");
		System.out.println("I" + "\t" + "Xl" + "\t \t" + "Xu" + "\t \t" + "Xr" + "\t \t" + "Fxl" + "\t \t" + "Fxu" + "\t \t" + "Fxr" + "\t \t" + "FxlFxr" + "\t \t" + "Et" + "\t \t" + "Ea");
		
		for (int i = 0; i < numi; i++) 
		{
			if(i == 0)
			{
						
				fxl = evaluarExpresion(fx, xl);
				fxu = evaluarExpresion(fx, xu);
				xr =  (((xu * fxl) - (xl * fxu))/(fxl - fxu));		

				fxr = evaluarExpresion(fx, xr);
				fxlfxr= fxl*fxr;
				et = Math.abs(((raiz - xr)/raiz)*100);
				ea = 0;
				
				System.out.printf("%d \t %.8f \t  %.8f \t %.8f \t %.8f \t %.8f \t %.8f \t %.8f \t %.8f \t %.8f \n", i, xl,xu,xr,fxl,fxu,fxr,fxlfxr,et, ea);
				continue;
			}
			else
			{
				antxr = xr;
					
				fxl = evaluarExpresion(fx, xl);
				fxu = evaluarExpresion(fx, xu);
				
				xr =  (((xu * fxl) - (xl * fxu))/(fxl - fxu));		

				fxr = evaluarExpresion(fx, xr);
				fxlfxr= fxl*fxr;
				et = Math.abs(((raiz - xr)/raiz)*100);
				ea = Math.abs(((xr-antxr)/xr)*100);	
				System.out.printf("%d \t %.8f \t  %.8f \t %.8f \t %.8f \t %.8f \t %.8f \t %.8f \t %.8f \t %.8f \n", i, xl,xu,xr,fxl,fxu,fxr,fxlfxr,et, ea);
				
			}
			if(fxlfxr > 0)
			{
				xl =xl;
				xu=xr;				
			}
			else
			{
				xu=xu;
				xl=xr;
			}
			if(ea<es)
			{
				break;
			}
		}
		reiniciar();
	}

	/**
	 * Metodo abierto de punto fijo
	 * @throws ScriptException 
	 */
	private static void puntoFijo() throws ScriptException 
	{
		// TODO Auto-generated method stub
		System.out.println("Metodo de punto fijo, por favor digite los siguientes valores:");
		
		System.out.println("Digite la ecuaci�n: ");
		String fx = "";
		Scanner entrada = new Scanner(System.in);
		fx = entrada.nextLine ();
		
		System.out.println("Digite el valor de Xi: ");
		String xl = "";
		Scanner entrada2 = new Scanner(System.in);
		xl = entrada2.nextLine ();
		
		System.out.println("Digite el valor de la raiz: ");
		String raizs = "";
		Scanner entrada4 = new Scanner(System.in);
		raizs = entrada4.nextLine ();
		
		System.out.println("Digite el numero de Iteraciones");
		String iteraciones = "";
		Scanner entrada5 = new Scanner(System.in);
		iteraciones = entrada5.nextLine ();
		
		double xi = Double.parseDouble(xl);		
		double raiz = Double.parseDouble(raizs);		
		int numi = Integer.parseInt(iteraciones);	
		double et = 0;
		double ea = 0;
		double antxi = 0;
		
		System.out.println("");
		System.out.println("I" + "\t" + "Xi" +  "\t \t" + "Et" + "\t \t" + "Ea");

		for (int i = 0; i < numi; i++) 
		{
			if(i==0)
			{
				et = Math.abs(((raiz - xi)/raiz)*100);		
			}
			else
			{
				antxi = xi;
				xi = evaluarExpresion(fx, antxi);
				et = Math.abs(((raiz - xi)/raiz)*100);
				ea = Math.abs(((xi-antxi)/xi)*100);
				
				
			}
			System.out.printf("%d \t %.8f \t  %.8f \t %.8f \n", i, xi,et, ea);
		}
		reiniciar();
		
	}
	
	/**
	 * Metodo abierto de Newton-Rhapson
	 * @throws ScriptException 
	 */
	private static void newtonRhapson() throws ScriptException
	{
		// TODO Auto-generated method stub
		System.out.println("Metodo de Newton-Rhapson, por favor digite los siguientes valores:");
		
		System.out.println("Digite la ecuaci�n: ");
		String fx = "";
		Scanner entrada = new Scanner(System.in);
		fx= entrada.nextLine ();
		
		System.out.println("Digite la derivada de la ecuaci�n: ");
		String ffx = "";
		Scanner entrada5 = new Scanner(System.in);
		ffx = entrada5.nextLine ();
		
		System.out.println("Digite el valor de Xi: ");
		String xl = "";
		Scanner entrada2 = new Scanner(System.in);
		xl = entrada2.nextLine ();
		
		System.out.println("Digite el valor de la raiz: ");
		String raizs = "";
		Scanner entrada4 = new Scanner(System.in);
		raizs = entrada4.nextLine ();
		
		
		double xi = Double.parseDouble(xl);		
		double raiz = Double.parseDouble(raizs);			
		double et = 0;
		double ea = 0;
		double antxi = 0;
		double fxi = 0;
		double ffxi= 0;
		
		System.out.println("");
		System.out.println("I" + "\t" + "Xi" +  "\t \t" + "F(x)" +  "\t \t" + "F'(x)"  +  "\t \t" + "Et" + "\t \t" + "Ea");

		for (int i = 0; i < 10; i++) 
		{
			if(i==0)
			{
				et = Math.abs(((raiz - xi)/raiz)*100);		
				fxi = evaluarExpresion(fx, xi);
				ffxi= evaluarExpresion(ffx, xi);
			}
			else
			{
				antxi = xi;
				xi= antxi - (fxi/ffxi);
				fxi = evaluarExpresion(fx, xi);
				ffxi= evaluarExpresion(ffx, xi);
				et = Math.abs(((raiz - xi)/raiz)*100);
				ea = Math.abs(((xi-antxi)/xi)*100);
				
				
			}
			System.out.printf("%d \t %.8f \t  %.8f \t  %.8f\t  %.8f \t %.8f \n", i, xi,fxi,ffxi,et, ea);
		}
		reiniciar();
		
	}
	
	/**
	 * Metodo abierto de Secante
	 * @throws ScriptException 
	 */
	private static void secante() throws ScriptException 
	{
		System.out.println("Metodo de secante, por favor digite los siguientes valores:");
		
		System.out.println("Digite la ecuaci�n: ");
		String fx = "";
		Scanner entrada = new Scanner(System.in);
		fx = entrada.nextLine ();
		
		System.out.println("Digite el valor de X-1: ");
		String x1 = "";
		Scanner entrada2 = new Scanner(System.in);
		x1 = entrada2.nextLine ();
		
		System.out.println("Digite el valor de X0: ");
		String x_0 = "";
		Scanner entrada3 = new Scanner(System.in);
		x_0 = entrada3.nextLine ();
		
		System.out.println("Digite el valor de la raiz: ");
		String raizs = "";
		Scanner entrada4 = new Scanner(System.in);
		raizs = entrada4.nextLine ();		
		
		System.out.println("Digite el valor de Estimado: ");
		String estimado = "";
		Scanner entrada6 = new Scanner(System.in);
		estimado = entrada6.nextLine ();
		
		System.out.println("Digite el numero de Iteraciones");
		String iteraciones = "";
		Scanner entrada5 = new Scanner(System.in);
		iteraciones = entrada5.nextLine ();
		
		double xi = Double.parseDouble(x1);
		double x0 = Double.parseDouble(x_0);
		double raiz = Double.parseDouble(raizs);			
		double et = 0;
		double ea = 0;
		double antxi = 0;
		double antxi2 = 0;
		double fxi = 0;
		double fx0 = 0;
		double es=Double.parseDouble(estimado);
		int numi = Integer.parseInt(iteraciones);
		
		System.out.println("");
		System.out.println("I" + "\t" + "Xi" +  "\t \t" + "F(x)"  +  "\t \t" + "Et" + "\t \t" + "Ea");

		for (int i = -1; i < numi; i++) 
		{
			if(i==-1)
			{
				et = Math.abs(((raiz - xi)/raiz)*100);		
				fxi = evaluarExpresion(fx, xi);
				System.out.printf("%d \t %.8f \t  %.8f \t  %.8f \t %.8f \n", i, xi,fxi,et, ea);
				continue;
			}
			else if( i == 0)
			{
				et = Math.abs(((raiz - x0)/raiz)*100);		
				fx0 = evaluarExpresion(fx, x0);
				ea = Math.abs(((x0-xi)/x0)*100);
				antxi = x0;
				antxi2 = xi;
				
			}
			else
			{								
				xi = antxi-((fx0*(antxi2-antxi))/(fxi-fx0));				
				fxi = fx0;				
				fx0 = evaluarExpresion(fx, xi);
				et = Math.abs(((raiz - xi)/raiz)*100);
				ea = Math.abs(((xi-antxi)/xi)*100);				
				antxi2 = antxi;
				antxi = xi;
			}
			System.out.printf("%d \t %.8f \t  %.8f \t  %.8f \t %.8f \n", i, xi,fx0,et, ea);
			if(ea< es)
			{
				break;
			}
		}
		reiniciar();
	}

	

	

	
	

	
	
	private static void reiniciar()
	{
		System.out.println("");
		System.out.println("�Desea volver a usar el programa?");
		System.out.println("0.- No ");
		System.out.println("1.- Si");
		
		System.out.println("Digite la opci�n deseada: "); 
		String opcion = "";
		Scanner entrada = new Scanner(System.in);
		opcion = entrada.nextLine ();
		
		if( opcion.equals("0"))
		{
			System.out.println("Gracias por usar el programa. ");
		}
		else if( opcion.equals("1"))
		{
			menuInicial();
		}
		else
		{
			System.out.println("Por favor ingrese un valor valido.");
			reiniciar();
		}
		
	}
	
	private static void menuDeAyuda() 
	{
		// TODO Auto-generated method stub
		System.out.println("");
		System.out.println("Aplicaci�n desarrollada por Jos� Daniel Barrero Barrios");
		reiniciar();
	}
	
	public static double evaluarExpresion(String ecuacion, double valor) throws ScriptException 
	{
		String variable = "@x";
		boolean aux;
		String retorno = new String();
		retorno = ecuacion;
		do {
			retorno = retorno.replace(variable, "("+valor+")");
			aux = retorno.matches(variable);
		} while (aux != false);
		return (double) engine.eval(retorno);
	}
}
	
	


