import java.util.*;
import java.lang.*;

public class main {

	
	
	public static void main(String[] args) 
	{
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// MENU INICIAL																									////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		menuInicial();
        
	}
	
	public static void menuInicial()
	{
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// MENU INICIAL																									////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		System.out.println("");
		System.out.println("Elige una opci�n"); 
		System.out.println("0.- Salir ");
		System.out.println("1.- Caso del paracaidista");
		System.out.println("2.- Ayuda");
		
		System.out.println("Digite la opci�n deseada: "); 
		String opcion = "";
		Scanner entrada = new Scanner(System.in);
		opcion = entrada.nextLine ();
		
		if( opcion.equals("0"))
		{
			System.out.println("Gracias por usar el programa. ");
		}
		else if( opcion.equals("1"))
		{
			casoParacaidista();
		}
		else if(opcion.equals("2"))
		{
			menuDeAyuda();
		}
		else
		{
			System.out.println("Por favor escriba una opcion valida.");
			menuInicial();
		}
		
	}
	private static void casoParacaidista() 
	{
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// Asignacion de Datos para el caso del paracaidista																////										////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		System.out.println("Bienvenido al Caso del paracaidista, por favor digite los siguientes valores:");
		
		System.out.println("Digite el valor de la gravedad (g)");
		String gravedad = "";
		Scanner entrada = new Scanner(System.in);
		gravedad = entrada.nextLine ();
		
		System.out.println("Digite el valor de la masa (m)");
		String masa = "";
		Scanner entrada2 = new Scanner(System.in);
		masa = entrada2.nextLine ();
		
		System.out.println("Digite el valor del Coeficiente de Resistencias del aire (c)");
		String resistenciaAire = "";
		Scanner entrada3 = new Scanner(System.in);
		resistenciaAire = entrada3.nextLine ();
		
		System.out.println("Digite el intervalo de tiempo ");
		String tiempo = "";
		Scanner entrada4 = new Scanner(System.in);
		tiempo = entrada4.nextLine ();
		
		int intervalo = Integer.parseInt(tiempo);
		double g = Double.parseDouble(gravedad);
		double m = Double.parseDouble(masa);
		double c = Double.parseDouble(resistenciaAire);
		
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//// Calculo de valores de la tabla																					////										////
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		// Valores iniciales
		
		ArrayList<Integer> t = new  ArrayList<Integer>(); 
		t.add(0);
		
		ArrayList<Double> velocidadAnalitica = new  ArrayList<Double>();
		velocidadAnalitica.add(0.0);
		
		ArrayList<Double> velocidadNumerica = new  ArrayList<Double>();
		velocidadNumerica.add(0.0);
		
		ArrayList<Double> ea = new  ArrayList<Double>();
		ea.add(0.0);
		
		ArrayList<Double> et = new  ArrayList<Double>();
		et.add(0.0);
		
		
		// Variables temporales
		
		double va = 0;
		double vn = 0;
		double ett = 0;
		double eaa = 0;
		int j = 1; // indice
		
		for (int i = intervalo; i <= 20; i+= intervalo) 
		{
			t.add(i);
			va = calculoVelocidadAnalitica(g, m, c, i);
			vn = velocidadNumerica.get(j-1) + ((g - ((c/m)*velocidadNumerica.get(j-1)))*(t.get(j)-t.get(j-1)));
			
			velocidadAnalitica.add(va);
			velocidadNumerica.add(vn);
			
			ett = ((velocidadAnalitica.get(j) - velocidadNumerica.get(j))/ velocidadAnalitica.get(j)) * 100;
			eaa = ((velocidadNumerica.get(j) - velocidadNumerica.get(j-1))/ velocidadNumerica.get(j)) * 100;
			ett = Math.abs(ett);
			eaa = Math.abs(eaa);
			ea.add(eaa);
			et.add(ett);
			j++;
			
		}
		
		imprimirTabla(t,velocidadAnalitica,velocidadNumerica,ea,et);
		
		
	}
	private static void imprimirTabla(ArrayList<Integer> t, ArrayList<Double> velocidadAnalitica,
			ArrayList<Double> velocidadNumerica, ArrayList<Double> ea, ArrayList<Double> et) 
	{
		
		System.out.println("");
		System.out.println("Tiempo (t)" + "\t" + "V Anal�tica" + "\t" + "V Num�rica" + "\t" + "Et" + "\t \t" + "Ea" + "\n");
		
		for (int i = 0; i < t.size(); i++) 
		{
			System.out.printf("%d \t \t %.8f \t %.8f \t %.8f \t %.8f \n", t.get(i),velocidadAnalitica.get(i),velocidadNumerica.get(i),et.get(i), ea.get(i));
		}
		
		reiniciar();
		// COLOCAR UN MENU DE DEVUELTA LA PRINCIPAL.
	}
	
	private static void reiniciar()
	{
		System.out.println("");
		System.out.println("�Desea volver a usar el programa?");
		System.out.println("0.- No ");
		System.out.println("1.- Si");
		
		System.out.println("Digite la opci�n deseada: "); 
		String opcion = "";
		Scanner entrada = new Scanner(System.in);
		opcion = entrada.nextLine ();
		
		if( opcion.equals("0"))
		{
			System.out.println("Gracias por usar el programa. ");
		}
		else if( opcion.equals("1"))
		{
			menuInicial();
		}
		else
		{
			System.out.println("Por favor ingrese un valor valido.");
			reiniciar();
		}
		
	}
	private static double calculoVelocidadAnalitica(double g, double m, double c, int t) 
	{
		double exponente = - (c/m)*t;
		double solucion = ((g*m)/c) * (1 -  Math.pow(Math.E, exponente));
		return solucion;
	}
	
	private static void menuDeAyuda() 
	{
		// TODO Auto-generated method stub
		System.out.println("");
		System.out.println("Hecho por: Jos� Daniel Barrero Barrios ");
		reiniciar();
	}
	
	
	

}
